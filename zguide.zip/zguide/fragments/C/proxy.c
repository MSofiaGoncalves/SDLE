zmq_proxy (frontend, backend, capture);
