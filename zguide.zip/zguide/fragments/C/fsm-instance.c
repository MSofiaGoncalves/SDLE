event_t next_event;         //  Next event
state_t state;              //  Current state
event_t event;              //  Current event
