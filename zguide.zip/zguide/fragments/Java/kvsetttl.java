Random rand = new Random(System.nanoTime());
kvmsg.setProp("ttl", "%d", rand.nextInt(30));
