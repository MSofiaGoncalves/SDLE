//  0MQ ZeroCopy is not supported in Java
