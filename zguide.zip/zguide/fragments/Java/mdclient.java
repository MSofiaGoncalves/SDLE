mdcliapi client = new mdcliapi(String broker);
void     client.destroy();
ZMsg     client.send(String service, ZMsg request);
