if (items.poll (1000) == -1)
    break;              //  Interrupted
