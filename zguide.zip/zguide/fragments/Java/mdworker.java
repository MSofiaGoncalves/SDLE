mdwrkapi worker = new mdwrkapi(String broker, String service);
void     worker.destroy();
ZMsg     worker.recv(ZMsg reply);
