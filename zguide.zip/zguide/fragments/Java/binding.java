socket.bind ("tcp://*:5555");
socket.bind ("tcp://*:9999");
socket.bind ("inproc://somename");
