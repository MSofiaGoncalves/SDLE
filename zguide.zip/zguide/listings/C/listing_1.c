zmq_send (requester, "Hello", 6, 0);
